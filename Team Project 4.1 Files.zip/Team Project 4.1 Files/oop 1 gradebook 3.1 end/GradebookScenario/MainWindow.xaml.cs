﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace GradebookScenario
{
    /// <summary>
    /// Contains interaction logic for MainWindow.xaml.
    /// </summary>
    [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.StyleCop.CSharp.MaintainabilityRules", "SA1401:FieldsMustBePrivate", Justification = "Encapsulation not yet taught.")]
    public partial class MainWindow : Window
    {
        /// <summary>
        /// The school's Blackboard system.
        /// </summary>
        public Gradebook Blackboard;

        /// <summary>
        /// Initializes a new instance.
        /// </summary>
        public MainWindow()
        {
            this.InitializeComponent();
        }

        /// <summary>
        /// Calculates a student's cumulative grade point average.
        /// </summary>
        /// <param name="sender">The object that initiated the event.</param>
        /// <param name="e">The event arguments for the event.</param>
        private void calculateCurrentStudentGpaButton_Click(object sender, RoutedEventArgs e)
        {
            // Define and initialize an accumulator variable to hold the sum
            // of all of the student's grade-point values.
            double gradePointTotal = 0;

            // Loop through the list of grade records.
            foreach (GradeRecord gr in this.Blackboard.CurrentStudent.Transcript.Grades)
            {
                // Add the current record's grade point value to the accumulator variable.
                gradePointTotal += gr.GradePointValue;
            }

            // Set the student transcript's cumulative grade point average field to the
            // accumulator variable divided by the number of grade records in the student's
            // transcript.
            this.Blackboard.CurrentStudent.Transcript.CumulativeGpa = gradePointTotal /
                this.Blackboard.CurrentStudent.Transcript.Grades.Count;
        }

        /// <summary>
        /// Retrieves the student's letter grade for the course "Object-Oriented Programming 1".
        /// </summary>
        /// <param name="sender">The object that initiated the event.</param>
        /// <param name="e">The event arguments for the event.</param>
        private void findOop1LetterGradeButton_Click(object sender, RoutedEventArgs e)
        {
            // Define and initialize a variable to hold the desired grade record once it is found.
            GradeRecord gradeRecord = null;

            // Loop through the list of grade records.
            foreach (GradeRecord gr in this.Blackboard.CurrentStudent.Transcript.Grades)
            {
                // If the Object-Oriented Programming 1 course was found...
                if (gr.CourseName == "OOP 1")
                {
                    // Set the variable to point to the current grade record.
                    gradeRecord = gr;

                    // Break out of the loop (no need to continue looking).
                    break;
                }
            }

            // If the OOP 1 course was found...
            if (gradeRecord != null)
            {
                // Retrieve the grade record's letter grade and store it in a variable.
                string letterGrade = gradeRecord.LetterGrade;
            }
        }

        /// <summary>
        /// Creates a gradebook and related objects.
        /// </summary>
        /// <param name="sender">The object that initiated the event.</param>
        /// <param name="e">The event arguments for the event.</param>
        private void newGradebookButton_Click(object sender, RoutedEventArgs e)
        {
            // Create an instance of the Gradebook class.
            this.Blackboard = new Gradebook();

            // Set field values of Blackboard.
            this.Blackboard.CurrentStudent = new Student();
            this.Blackboard.IsOnline = false;
            this.Blackboard.MyTheme = new Theme();
            this.Blackboard.StudentCalendar = new Calendar();
            this.Blackboard.Version = "42.37.1.1";

            // Set field values of the current student.
            this.Blackboard.CurrentStudent.Advisor = new Instructor();
            this.Blackboard.CurrentStudent.Id = 123456789;
            this.Blackboard.CurrentStudent.IsOnProbation = true;
            this.Blackboard.CurrentStudent.Name = "Arthur";
            this.Blackboard.CurrentStudent.ProgramName = "Computer Science";
            this.Blackboard.CurrentStudent.Transcript = new ReportCard();

            // Set field values of the advisor.
            this.Blackboard.CurrentStudent.Advisor.Assistant = new TeachingAssistant();
            this.Blackboard.CurrentStudent.Advisor.EmployeeNumber = 987654321;
            this.Blackboard.CurrentStudent.Advisor.Name = "Plato";
            this.Blackboard.CurrentStudent.Advisor.ProgramName = "Computer Science";

            // Set field values of the assistant.
            this.Blackboard.CurrentStudent.Advisor.Assistant.IsSleeping = true;
            this.Blackboard.CurrentStudent.Advisor.Assistant.Name = "Leon";
            this.Blackboard.CurrentStudent.Advisor.Assistant.Salary = 10500m;

            // Set field values of the transcript.
            this.Blackboard.CurrentStudent.Transcript.CumulativeGpa = 3.5;
            this.Blackboard.CurrentStudent.Transcript.Grades = new List<GradeRecord>();
            this.Blackboard.CurrentStudent.Transcript.Term = "2013-Fall";

            // Define a temporary grade record variable.
            GradeRecord gradeRecord;

            // Create an instance of the GradeRecord class (Database Concepts).
            gradeRecord = new GradeRecord();

            // Set field values of the Database Concepts grade record.
            gradeRecord.CourseName = "Database Concepts";
            gradeRecord.GradePointValue = 4.0;
            gradeRecord.LetterGrade = "A";
            gradeRecord.PercentageGrade = 0.94;

            // Add the Database Concepts grade record to the transcript's list of grades.
            this.Blackboard.CurrentStudent.Transcript.Grades.Add(gradeRecord);

            // Create an instance of the GradeRecord class (Web Design 1).
            gradeRecord = new GradeRecord();

            // Set field values of the Web Design 1 grade record.
            gradeRecord.CourseName = "Web Design 1";
            gradeRecord.GradePointValue = 3.0;
            gradeRecord.LetterGrade = "B";
            gradeRecord.PercentageGrade = 0.82;

            // Add the Web Design 1 grade record to the transcript's list of grades.
            this.Blackboard.CurrentStudent.Transcript.Grades.Add(gradeRecord);

            // Create an instance of the GradeRecord class (OOP 1).
            gradeRecord = new GradeRecord();

            // Set field values of the OOP 1 grade record.
            gradeRecord.CourseName = "OOP 1";
            gradeRecord.GradePointValue = 3.0;
            gradeRecord.LetterGrade = "B";
            gradeRecord.PercentageGrade = 0.85;

            // Add the OOP 1 grade record to the transcript's list of grades.
            this.Blackboard.CurrentStudent.Transcript.Grades.Add(gradeRecord);

            // Set field values of my theme.
            this.Blackboard.MyTheme.BackgroundColor = "White";
            this.Blackboard.MyTheme.FontColor = "Blue";
            this.Blackboard.MyTheme.FontIsBold = true;
            this.Blackboard.MyTheme.FontIsItalic = false;
            this.Blackboard.MyTheme.FontName = "Arial";
            this.Blackboard.MyTheme.FontSize = 10.5;
            this.Blackboard.MyTheme.IsHighContrast = false;
            this.Blackboard.MyTheme.Name = "NTC Default";

            // Set field values of the student calendar.
            this.Blackboard.StudentCalendar.CurrentDayName = "Monday";
            this.Blackboard.StudentCalendar.CurrentDayNumber = 26;
            this.Blackboard.StudentCalendar.CurrentMonth = "August";
            this.Blackboard.StudentCalendar.CurrentYear = 2042;
            this.Blackboard.StudentCalendar.ViewStyle = "Month";
        }
    }
}